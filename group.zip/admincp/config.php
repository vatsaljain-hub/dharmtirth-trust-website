        <?php
if ($con = mysqli_connect('localhost','root','','trust'))
{
    //echo "string";
}
else
{
    die("Failed to connect to Database"); 
}
?>